clear
data = load("COIL20.mat"); %载入数据
load('X0.mat') %载入初始解
data.X=data.X'; %样本
data.Y=data.Y'; %标签
options.maxiter   = 1000; %总迭代次数
options.s         = 100; %稀疏度
options.tol       = 1e-4; %停止条件值
options.i_x       = 1000; %流形优化迭代次数
options.X0        = X0_coil20; %松弛问题的解
options.mu        = 1000000; %惩罚稀释
class=zeros(size(data.X,2),50); %存储聚类结果
[out] =OURS(data,  options);
Y=out.X; %引入变量Y的解
X=out.Y; %稀疏矩阵X的解
idx=out.Tu; %根据稀疏情况得到相应特征的索引
D1=data.X(idx,:); %得到相应特征
D=D1';
for z=1:50   %50次聚类
    [id, I]=kmeans(D,length(unique(data.Y)),'MaxIter',200);
    class(:,z)=id;
end

