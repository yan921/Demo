  function [out] = OURS(data, options)
%% Get Data Sequence
A = data.X;     % samples data
B = data.Y;     % label

%% Initialization
if isfield(options,'maxiter');   maxiter   = options.maxiter;   else; maxiter   = 1e3;  end
if isfield(options,'mu');        mu        = options.mu;        else; mu        = 2^5;  end
if isfield(options,'s');         s         = options.s;         else; s         = 0.1;  end
if isfield(options,'tol');       tol       = options.tol;       else; tol       = 1e-5; end
if isfield(options,'X0');        X0        = options.X0;        else; X0        = 0;    end
if isfield(options,'i_x');       i_x       = options.i_x;       else; i_x       = 3000; end
[n,~]       = size(A);
ClassLabel  = unique(B);
p           = length(ClassLabel);
Y0          = X0  ;         % Initialize Y
%% Assign Data
X = X0;
Y_current = Y0;
%% Defining Functions
AA=A*A';
f_loss  = @(X)(-1)*trace(X'*AA*X);                                                 % loss function
Fnorm   = @(var)norm(var,'fro')^2;

%% Main
time_start=tic;
for iter = 1:maxiter                                                        
     %% update X 
    opts = [];  % no predefined parameter

    opts.X = X; % specific the initial point
    opts.info_warning = 0; % display costomized warning messages
    opts.stepsize.type = 'ABB'; % set stepsize as alternating Barzilai-Borwein stepsize
    opts.stepsize.max_stepsize = 1000; % specify the maximum stepsize to improve the robustness
    opts.stepsize.min_stepsize = 0; % specify the minimum stepsize to improve the robustness
    opts.stepsize.init_stepsize = 1e-2; % specify the initial stepsize
    opts.gtol = 1e-8; % set the stopping criteria
    opts.local_info = 0; % set the display mode
    opts.postprocess = 1; % turn on the post-process 
    opts.linesearch = 0; % no linsearch
    opts.maxit = i_x;
    [Out] = stop_pencf(@funch1,opts,Y_current,mu,AA);
    X = Out.X;        % update X
    %% update Y
    Y_old            = Y_current;
    [~,Tu]           = maxk( sum(X,2),s,'ComparisonMethod','abs');    % Find the support indices Tu
    Y_current        = zeros(n,p);
    Y_current(Tu,:)  = X(Tu,:); 

    f_cost = (f_loss(X)+mu*(norm(X-Y_current,'fro')^2));   
    obj(iter) = f_cost;                               % calculate the loss function
 %%  check the stop criteria
    if iter>1
        error_obj(iter) = abs(obj(iter)-obj(iter-1))/(1+abs(obj(iter-1)));      % error_obj
%         error_Y(iter)   = Fnorm(Y_current-Y_old)/(1+Fnorm(Y_old));              % error_Y
        fprintf('%5d\t  %6.2e\t %6.2e\n ',iter, obj(iter), error_obj(iter));
        if (error_obj(iter) <tol); break; end
        if iter == maxiter; fprintf('The number of iterations reaches maxiter.\n'); end
    end
end
time = toc(time_start);
out.Y           = Y_current;
out.X           = X;
out.obj         = obj';
out.iter        = iter;
out.Error_obj   = error_obj;
out.time        = time;
out.Tu          = Tu;
out.X0          = X0;
out.Y0          = Y0;
out.mu          = mu;
end

function [h_loss, h_grad] = funch1(X,Y,mu,AA)
%% Calculate the gradient and function values of h                                                              %% Calculate the gradient and function values of h
        X_local  = X;     
        h_grad  = -AA*X_local+2*mu*(X_local-Y);
        h_loss =(-1)*trace(X'*AA*X) + mu*(norm(X_local-Y,'fro')^2);                                 
end